package com.teams4.blog.forget;

import androidx.appcompat.app.AppCompatActivity;
import com.teams4.blog.R;


import android.os.Bundle;

public class ForgetCodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_code);
    }
}
